import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmhvcml6b25pcHR2')

name = b.b64decode('SG9yaXpvbiBJUFRW')

server1host = 'http://horizonhosting.xyz'
server1port = '80'

server2host = 'http://horizongoldtv.ddns.net'
server2port = '80'

